package com.example.prima_pagina;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//pentru amprenta
import android.annotation.SuppressLint;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.biometric.BiometricManager;
import androidx.core.hardware.fingerprint.FingerprintManagerCompat;
import androidx.biometric.BiometricPrompt;
import java.security.KeyPair;
import java.util.concurrent.Executor;

import android.util.Log;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt.AuthenticationCallback;
import androidx.biometric.BiometricPrompt.AuthenticationResult;


public class Amprenta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_amprenta);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public static int hasBiometricCapability(Context context) {
        @SuppressLint("ServiceCast") BiometricManager biometricManager = (BiometricManager) context.getSystemService(Context.FINGERPRINT_SERVICE);
        if (biometricManager != null) {
            return biometricManager.canAuthenticate();
        } else {
            // Handle case where BiometricManager is unavailable (optional)
            return BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE; // Example error code
        }
    }

    public static boolean isBiometricReady(Context context) {
        return hasBiometricCapability(context) == BiometricManager.BIOMETRIC_SUCCESS;
    }

    public static BiometricPrompt.PromptInfo createBiometricPromptInfo(String title, String subtitle, String description, boolean allowDeviceCredential) {
        BiometricPrompt.PromptInfo.Builder builder = new BiometricPrompt.PromptInfo.Builder();
        builder.setTitle(title);
        builder.setSubtitle(subtitle);
        builder.setDescription(description);

        // Set button based on allowDeviceCredential flag
        if (allowDeviceCredential) {
            builder.setDeviceCredentialAllowed(true);
        } else {
            builder.setNegativeButtonText("Cancel");
        }

        return builder.build();
    }

    public interface BiometricAuthListener {
        void onBiometricAuthenticationSuccess(BiometricPrompt.AuthenticationResult result);
        void onBiometricAuthenticationError(int errorCode, String errorMessage);
        void onBiometricAuthenticationFailed();
    }

    public static BiometricPrompt initBiometricPrompt(AppCompatActivity activity, BiometricAuthListener listener) {
        // 1. Executor using ContextCompat (optional)
        // Executor executor = ContextCompat.getMainExecutor(activity);

        // 2. Authentication Callback implementation
        BiometricPrompt.AuthenticationCallback callback = new BiometricPrompt.AuthenticationCallback() {

            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                listener.onBiometricAuthenticationSuccess(result);
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                listener.onBiometricAuthenticationError(errorCode, errString.toString());
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Log.w(this.getClass().getSimpleName(), "Authentication failed for an unknown reason");
                listener.onBiometricAuthenticationFailed();
            }
        };

        // 3. Create and return BiometricPrompt
        Executor executor = ContextCompat.getMainExecutor(activity);
        return new BiometricPrompt(activity, executor, callback);
    }

    public static void showBiometricPrompt(String title, String subtitle, String description,
                                           AppCompatActivity activity,
                                           BiometricAuthListener listener,
                                           BiometricPrompt.CryptoObject cryptoObject,
                                           boolean allowDeviceCredential) {

        // 1. Create BiometricPrompt Info
        BiometricPrompt.PromptInfo promptInfo = createBiometricPromptInfo(title, subtitle, description, allowDeviceCredential);

        // 2. Initialize BiometricPrompt
        BiometricPrompt biometricPrompt = initBiometricPrompt(activity, listener);

        // 3. Authenticate with or without CryptoObject
        if (cryptoObject == null) {
            biometricPrompt.authenticate(promptInfo);
        } else {
            biometricPrompt.authenticate(promptInfo, cryptoObject);
        }
    }

    public void onClickBiometrics(View view) {
       // showBiometricPrompt( "Biometric Authentication","Enter biometric credentials to proceed.","Input your Fingerprint or FaceID to ensure it's you!", this, this, null, true);
    }


}